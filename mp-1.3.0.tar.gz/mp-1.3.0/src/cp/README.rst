cp
==

An AMPL function library that provides functions used by
constraint programming solvers.
