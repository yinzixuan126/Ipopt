long ASLdate_ASL = 20150101;
